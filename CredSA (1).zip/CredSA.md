```python
#Import essential libraries

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import warnings
```


```python
#read file

df = pd.read_csv('/Users/mac/Downloads/Data Analyst Assessment Dataset/Assessment Dataset -.csv')
df.head()

(df['Status'] == 'Successful').sum()

#noticed an error with electricity
df['product'] = df['product'].str.capitalize()
```


```python
# null check

df.isna().sum()

#the output here shows Updated Time and Vendiing channel column both have null values of 5195 and 3 respectively
```




    Customer ID               0
    Recipient                 0
    Amount                    0
    Tranx_Date                0
    Tranx ID                  0
    Updated Time           5195
    Buying Price              0
    Transaction Gateway       0
    Seller Name               0
    Vending Channel           3
    Account Type              0
    Location                  0
    product                   0
    Status                    0
    dtype: int64




```python
#check for dupes in Txn_id column just because having duplicatted Txn_id poses a problem.

df[df.duplicated(subset=['Tranx ID'], keep=False)]
# The output shows we are cleared off dupes with respect to Txn_id. This is good.
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Recipient</th>
      <th>Amount</th>
      <th>Tranx_Date</th>
      <th>Tranx ID</th>
      <th>Updated Time</th>
      <th>Buying Price</th>
      <th>Transaction Gateway</th>
      <th>Seller Name</th>
      <th>Vending Channel</th>
      <th>Account Type</th>
      <th>Location</th>
      <th>product</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
# modal imputationton to fill up nulls on Updated Time and Vending Channel Columns

for col in df.columns:
    if df[col].isna().sum() > 0:
        df[col].fillna(df[col].mode()[0], inplace=True)

df.isna().sum()
```




    Customer ID            0
    Recipient              0
    Amount                 0
    Tranx_Date             0
    Tranx ID               0
    Updated Time           0
    Buying Price           0
    Transaction Gateway    0
    Seller Name            0
    Vending Channel        0
    Account Type           0
    Location               0
    product                0
    Status                 0
    is_success             0
    response_time          0
    dtype: int64




```python
# Standardize Status column

df['Status'] = df['Status'].str.upper().str.strip()
```


```python
# OneHot Encoding status column; just lke case when in sql
df['is_success'] = np.where(df['Status'] == 'SUCCESSFUL', 1, 0)
df['is_success'].sum()
```




    np.int64(643456)



# 1. In your view identify KPI's to track with reasons backed up with report/Analysis


```python
#overview
transaction_summary = df['Status'].value_counts()
transaction_summary
```




    Status
    SUCCESSFUL                           643456
    OTHER ERRORS                           2416
    TOO MUCH REQUESTS/SYSTEM TOO BUSY      1033
    VALIDATION ERROR                        736
    WRONG PRODUCT                           605
    Name: count, dtype: int64



## A. TRANSACTION SUCCESS RATE:

Since the dataset contains Produuct Transaction Details; Customer ID, Amount, Buying Price, Product, Status, Tranx_Date, Updated Time, Transaction Gateway, Vending Channel and Location, it is therefore tantamount that the KPI's based on surface perception should include measures that speak to both Business and product performance as well as customers interaction.
Hence, Measures that speak to Revenue, Reliability, Performance, Profitability and Customer behavior would readily come to mind.

Transaction Success Rate basically measures System reliability and customer performance

it is basically expressed as; TSR = Successful Transactions / Total Transactions

This is key in Detecting failing integrations, Identifying unstable customers, Platform performance measurement



```python
# Calculate Transaction Success Rate by Location and Product

success_rate = (
    df.groupby(['Location', 'product']).agg(
        total_transactions=('is_success', 'count'),
        successful_transactions=('is_success', 'sum')
    ).reset_index()
)
success_rate['success_rate'] = ((success_rate['successful_transactions'] / success_rate['total_transactions'])* 100).round(2)

# average success rate by location
location_avg = success_rate.groupby('Location')['success_rate'].mean().round(2).reset_index()
location_avg.rename(columns={'success_rate': 'avg_location_success_rate'}, inplace=True)

# append the average 
success_rate = success_rate.merge(location_avg, on='Location', how='left')

# Sort values by Location first, then by success_rate in descending order
success_rate = success_rate.sort_values(['Location', 'success_rate'], ascending=[True, False])

# Display the DataFrame without the default index
success_rate.reset_index(drop=True, inplace=True)
success_rate
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Location</th>
      <th>product</th>
      <th>total_transactions</th>
      <th>successful_transactions</th>
      <th>success_rate</th>
      <th>avg_location_success_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Canada</td>
      <td>airtime</td>
      <td>10514</td>
      <td>10182</td>
      <td>96.84</td>
      <td>78.63</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Canada</td>
      <td>data</td>
      <td>1979</td>
      <td>1888</td>
      <td>95.40</td>
      <td>78.63</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Canada</td>
      <td>pin</td>
      <td>300</td>
      <td>236</td>
      <td>78.67</td>
      <td>78.63</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Canada</td>
      <td>cabletv</td>
      <td>3</td>
      <td>2</td>
      <td>66.67</td>
      <td>78.63</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Canada</td>
      <td>Electricity</td>
      <td>18</td>
      <td>10</td>
      <td>55.56</td>
      <td>78.63</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Nigeria</td>
      <td>electricity</td>
      <td>22</td>
      <td>22</td>
      <td>100.00</td>
      <td>98.05</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Nigeria</td>
      <td>startimes</td>
      <td>28</td>
      <td>28</td>
      <td>100.00</td>
      <td>98.05</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Nigeria</td>
      <td>airtime</td>
      <td>405656</td>
      <td>404249</td>
      <td>99.65</td>
      <td>98.05</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Nigeria</td>
      <td>data</td>
      <td>99723</td>
      <td>98104</td>
      <td>98.38</td>
      <td>98.05</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Nigeria</td>
      <td>pin</td>
      <td>938</td>
      <td>904</td>
      <td>96.38</td>
      <td>98.05</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Nigeria</td>
      <td>cabletv</td>
      <td>98</td>
      <td>92</td>
      <td>93.88</td>
      <td>98.05</td>
    </tr>
    <tr>
      <th>11</th>
      <td>UK</td>
      <td>pin</td>
      <td>1</td>
      <td>1</td>
      <td>100.00</td>
      <td>95.77</td>
    </tr>
    <tr>
      <th>12</th>
      <td>UK</td>
      <td>airtime</td>
      <td>101145</td>
      <td>100807</td>
      <td>99.67</td>
      <td>95.77</td>
    </tr>
    <tr>
      <th>13</th>
      <td>UK</td>
      <td>cabletv</td>
      <td>341</td>
      <td>335</td>
      <td>98.24</td>
      <td>95.77</td>
    </tr>
    <tr>
      <th>14</th>
      <td>UK</td>
      <td>data</td>
      <td>26643</td>
      <td>25895</td>
      <td>97.19</td>
      <td>95.77</td>
    </tr>
    <tr>
      <th>15</th>
      <td>UK</td>
      <td>Electricity</td>
      <td>837</td>
      <td>701</td>
      <td>83.75</td>
      <td>95.77</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Pivot for plot

pivot_df = success_rate.pivot(
    index='Location',
    columns='product',
    values='success_rate'
)
pivot_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>product</th>
      <th>Airtime</th>
      <th>Cabletv</th>
      <th>Data</th>
      <th>Electricity</th>
      <th>Pin</th>
      <th>Startimes</th>
    </tr>
    <tr>
      <th>Location</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Canada</th>
      <td>96.84</td>
      <td>66.67</td>
      <td>95.40</td>
      <td>55.56</td>
      <td>78.67</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>Nigeria</th>
      <td>99.65</td>
      <td>93.88</td>
      <td>98.38</td>
      <td>100.00</td>
      <td>96.38</td>
      <td>100.0</td>
    </tr>
    <tr>
      <th>UK</th>
      <td>99.67</td>
      <td>98.24</td>
      <td>97.19</td>
      <td>83.75</td>
      <td>100.00</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Heatmap Plot:

plt.figure(figsize=(7, 4))
sns.heatmap(
    pivot_df,
    annot=True,
    fmt=".1f",
    cmap="RdYlGn",
    linewidths=0.5,
    linecolor='white'
)
plt.title("Transaction Success Rate by Location & Product", fontsize=16, fontweight='bold')
plt.ylabel("Location", fontsize=12, fontweight='bold')
plt.xlabel("Product", fontsize=12, fontweight='bold')
plt.xticks(rotation=45, ha='right', fontweight='bold')
plt.yticks(rotation=0, fontweight='bold')
plt.tight_layout()
plt.show()

```


    
![png](output_13_0.png)
    



```python
# Alternative: Barplot

plt.figure(figsize=(8, 4))
sns.barplot(
    data=success_rate,
    x='Location',
    y='avg_location_success_rate',
    color='#90EE90',
    edgecolor='black'
)
plt.title("Avg Transaction Success Rate by Location", fontsize=18, fontweight='bold')
plt.xlabel('Location', fontsize=14)
plt.ylabel('Avg Success Rate (%)', fontsize=14)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()
```


    
![png](output_14_0.png)
    


We see the TSR rate measured here:
Nigeria has → 98% success
UK has  = 96% success
Canada has = 79% success

## B. FAILURE RATE:


```python
Failure Rate (can also replicate the same as above for Failure Rate)
This is vital because it measures Transaction reliability risk
expressed as : Failure Rate = Failed / Total

It is as analysed in question 5
```

## C. ESTIMATED GROSS PROFIT

This measures business profitability and is basically expressed as Gross Profit = Amount − Buying Price
Why it matters

It can also be used to segment customers based on Profit generation
Some customers:



```python
df['Gross Profit'] = df['Amount'] - df['Buying Price']
total_gross_profit = df['Gross Profit'].sum()
print(f"Total Gross Profit: {total_gross_profit:.2f}")
```

    Total Gross Profit: 14250030.70



```python

```

## D. AVERAGE RESPONSE TIME (Performance KPI)

This basically measures system laxity, expressed as Response Time = Updated Time − Tranx_Date

Slow response might lead to: duplicate transactions, increased timeouts and number of retries, customer complaints etc

for. instance, if Product Avg Response is
Airtime: 1 sec
Data: 5 sec
it can be concluded that Data product has latency issue.


```python

```


```python
success_value = df[df['Status']=="SUCCESSFUL"].groupby('Customer ID')
#success_value.head()
```


```python

```

## 2. Average Response Time per Product


```python
df['response_time'] = pd.to_datetime(df['Tranx_Date']) - pd.to_datetime(df['Updated Time'])

avg_response = df.groupby('product')['response_time'].mean()

avg_response
```




    product
    Airtime       0 days 00:26:33.993516522
    Cabletv       3 days 08:59:45.690045248
    Data          0 days 01:11:44.863843546
    Electricity   2 days 22:39:54.637400228
    Pin           0 days 00:24:41.803066989
    Startimes     3 days 08:45:36.071428571
    Name: response_time, dtype: timedelta64[ns]




```python
# Visual for Average Response Time per Product

avg_response_hours = avg_response.dt.total_seconds() / 3600
plt.figure(figsize=(10, 6))
avg_response_hours.plot(kind='bar', color='#90EE90', edgecolor='black')
plt.title('Average Response Time per Product', fontsize=16)
plt.xlabel('Product', fontsize=12)
plt.ylabel('Average Response Time (hours)', fontsize=12)
plt.xticks(rotation=45, ha='right')
plt.tight_layout()
plt.show()


# The lower the better
```


    
![png](output_29_0.png)
    



```python

```

## 3. Daily Trend Chart for Top 5 Customers


```python
# ensure datetime
df['Tranx_Date'] = pd.to_datetime(df['Tranx_Date']).dt.date

# filter top5
trend = df[df['Customer ID'].isin(top5)]

# loop and plot each customer
for cust in top5:
    
    cust_df = (
        trend[trend['Customer ID'] == cust]
        .groupby('Tranx_Date')['Amount']
        .sum()
        .sort_index()
    )

    plt.figure(figsize=(12,4))
    
    plt.plot(
        cust_df.index,
        cust_df.values,
        color = 'green',
        marker='o',
        linewidth=2
    )
    
    plt.title(f"Daily Transaction Trend — Customer {cust}")
    plt.xlabel("Transaction Date")
    plt.ylabel("Amount")
    plt.xticks(rotation=45)

    plt.tight_layout()
    plt.show()
```


    
![png](output_32_0.png)
    



    
![png](output_32_1.png)
    



    
![png](output_32_2.png)
    



    
![png](output_32_3.png)
    



    
![png](output_32_4.png)
    


## merged line chart


```python
fig = go.Figure()

# Add a trace for each customer
for cust in top5:
    cust_data = daily_amounts[daily_amounts['Customer ID'] == cust]

    fig.add_trace(go.Scatter(
        x=cust_data['Tranx_Date'],
        y=cust_data['Amount'],
        mode='lines+markers',
        name=f'Customer {cust}',
        showlegend=True,          # ensure one legend entry only
        marker=dict(size=6),
        line=dict(width=2),
        hovertemplate='<b>Date</b>: %{x}<br><b>Amount</b>: %{y:,.2f}<extra></extra>'
    ))

    # add ONLY one max annotation per customer
    if not cust_data.empty:
        max_point = cust_data.loc[cust_data['Amount'].idxmax()]

        fig.add_annotation(
            x=max_point['Tranx_Date'],
            y=max_point['Amount'],
            text=f"{cust}<br>{max_point['Amount']:,.0f}",
            showarrow=True,
            arrowhead=2,
            ax=0,
            ay=-30,
            font=dict(size=10),
            bgcolor="white"
        )

# Layout
fig.update_layout(
    title='Daily Transaction Trends for Top 5 Customers',
    xaxis_title='Transaction Date',
    yaxis_title='Total Amount',
    template='plotly_white',
    hovermode='x unified',   # cleaner hover
    height=600,
    width=1000,

    legend=dict(
        orientation="h",
        yanchor="bottom",
        y=1.02,
        xanchor="center",
        x=0.5
    ),

    xaxis=dict(
        tickangle=45
    )
)

fig.show()
```


<div>                            <div id="838c8503-a176-4161-ac33-4442c23ecbd6" class="plotly-graph-div" style="height:600px; width:1000px;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("838c8503-a176-4161-ac33-4442c23ecbd6")) {                    Plotly.newPlot(                        "838c8503-a176-4161-ac33-4442c23ecbd6",                        [{"hovertemplate":"\u003cb\u003eDate\u003c\u002fb\u003e: %{x}\u003cbr\u003e\u003cb\u003eAmount\u003c\u002fb\u003e: %{y:,.2f}\u003cextra\u003e\u003c\u002fextra\u003e","line":{"width":2},"marker":{"size":6},"mode":"lines+markers","name":"Customer 412476446244","showlegend":true,"x":["2024-11-24T00:00:00","2024-11-25T00:00:00","2024-11-26T00:00:00","2024-11-27T00:00:00","2024-11-28T00:00:00","2024-11-29T00:00:00","2024-11-30T00:00:00"],"y":[57117232.0,62462454.12,64586172.0,68641948.0,59452134.53,60370811.74,63485370.01],"type":"scatter"},{"hovertemplate":"\u003cb\u003eDate\u003c\u002fb\u003e: %{x}\u003cbr\u003e\u003cb\u003eAmount\u003c\u002fb\u003e: %{y:,.2f}\u003cextra\u003e\u003c\u002fextra\u003e","line":{"width":2},"marker":{"size":6},"mode":"lines+markers","name":"Customer 8304555449023","showlegend":true,"x":["2024-11-24T00:00:00","2024-11-25T00:00:00","2024-11-26T00:00:00","2024-11-27T00:00:00","2024-11-28T00:00:00","2024-11-29T00:00:00","2024-11-30T00:00:00"],"y":[14242763.0,16212408.98,16508958.0,16786826.0,17842159.0,16326696.11,14489732.0],"type":"scatter"},{"hovertemplate":"\u003cb\u003eDate\u003c\u002fb\u003e: %{x}\u003cbr\u003e\u003cb\u003eAmount\u003c\u002fb\u003e: %{y:,.2f}\u003cextra\u003e\u003c\u002fextra\u003e","line":{"width":2},"marker":{"size":6},"mode":"lines+markers","name":"Customer 9315518483834","showlegend":true,"x":["2024-11-24T00:00:00","2024-11-25T00:00:00","2024-11-26T00:00:00","2024-11-27T00:00:00","2024-11-28T00:00:00","2024-11-29T00:00:00","2024-11-30T00:00:00"],"y":[12279331.0,12068365.0,12596485.0,12193223.0,12212115.0,12844650.0,13268798.0],"type":"scatter"},{"hovertemplate":"\u003cb\u003eDate\u003c\u002fb\u003e: %{x}\u003cbr\u003e\u003cb\u003eAmount\u003c\u002fb\u003e: %{y:,.2f}\u003cextra\u003e\u003c\u002fextra\u003e","line":{"width":2},"marker":{"size":6},"mode":"lines+markers","name":"Customer 431539048016","showlegend":true,"x":["2024-11-24T00:00:00","2024-11-25T00:00:00","2024-11-26T00:00:00","2024-11-27T00:00:00","2024-11-28T00:00:00","2024-11-29T00:00:00","2024-11-30T00:00:00"],"y":[5495702.0,7379255.0,7587374.0,8006467.0,7539424.0,7409402.0,7482575.0],"type":"scatter"},{"hovertemplate":"\u003cb\u003eDate\u003c\u002fb\u003e: %{x}\u003cbr\u003e\u003cb\u003eAmount\u003c\u002fb\u003e: %{y:,.2f}\u003cextra\u003e\u003c\u002fextra\u003e","line":{"width":2},"marker":{"size":6},"mode":"lines+markers","name":"Customer 138455421218","showlegend":true,"x":["2024-11-24T00:00:00","2024-11-25T00:00:00","2024-11-26T00:00:00","2024-11-27T00:00:00","2024-11-28T00:00:00","2024-11-29T00:00:00","2024-11-30T00:00:00"],"y":[4712387.0,6446644.0,6532994.0,6514525.0,6417331.0,5444172.0,5928493.0],"type":"scatter"}],                        {"template":{"data":{"barpolar":[{"marker":{"line":{"color":"white","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"barpolar"}],"bar":[{"error_x":{"color":"#2a3f5f"},"error_y":{"color":"#2a3f5f"},"marker":{"line":{"color":"white","width":0.5},"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"bar"}],"carpet":[{"aaxis":{"endlinecolor":"#2a3f5f","gridcolor":"#C8D4E3","linecolor":"#C8D4E3","minorgridcolor":"#C8D4E3","startlinecolor":"#2a3f5f"},"baxis":{"endlinecolor":"#2a3f5f","gridcolor":"#C8D4E3","linecolor":"#C8D4E3","minorgridcolor":"#C8D4E3","startlinecolor":"#2a3f5f"},"type":"carpet"}],"choropleth":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"choropleth"}],"contourcarpet":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"contourcarpet"}],"contour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"contour"}],"heatmapgl":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmapgl"}],"heatmap":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"heatmap"}],"histogram2dcontour":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2dcontour"}],"histogram2d":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"histogram2d"}],"histogram":[{"marker":{"pattern":{"fillmode":"overlay","size":10,"solidity":0.2}},"type":"histogram"}],"mesh3d":[{"colorbar":{"outlinewidth":0,"ticks":""},"type":"mesh3d"}],"parcoords":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"parcoords"}],"pie":[{"automargin":true,"type":"pie"}],"scatter3d":[{"line":{"colorbar":{"outlinewidth":0,"ticks":""}},"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatter3d"}],"scattercarpet":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattercarpet"}],"scattergeo":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergeo"}],"scattergl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattergl"}],"scattermapbox":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scattermapbox"}],"scatterpolargl":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolargl"}],"scatterpolar":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterpolar"}],"scatter":[{"fillpattern":{"fillmode":"overlay","size":10,"solidity":0.2},"type":"scatter"}],"scatterternary":[{"marker":{"colorbar":{"outlinewidth":0,"ticks":""}},"type":"scatterternary"}],"surface":[{"colorbar":{"outlinewidth":0,"ticks":""},"colorscale":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"type":"surface"}],"table":[{"cells":{"fill":{"color":"#EBF0F8"},"line":{"color":"white"}},"header":{"fill":{"color":"#C8D4E3"},"line":{"color":"white"}},"type":"table"}]},"layout":{"annotationdefaults":{"arrowcolor":"#2a3f5f","arrowhead":0,"arrowwidth":1},"autotypenumbers":"strict","coloraxis":{"colorbar":{"outlinewidth":0,"ticks":""}},"colorscale":{"diverging":[[0,"#8e0152"],[0.1,"#c51b7d"],[0.2,"#de77ae"],[0.3,"#f1b6da"],[0.4,"#fde0ef"],[0.5,"#f7f7f7"],[0.6,"#e6f5d0"],[0.7,"#b8e186"],[0.8,"#7fbc41"],[0.9,"#4d9221"],[1,"#276419"]],"sequential":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]],"sequentialminus":[[0.0,"#0d0887"],[0.1111111111111111,"#46039f"],[0.2222222222222222,"#7201a8"],[0.3333333333333333,"#9c179e"],[0.4444444444444444,"#bd3786"],[0.5555555555555556,"#d8576b"],[0.6666666666666666,"#ed7953"],[0.7777777777777778,"#fb9f3a"],[0.8888888888888888,"#fdca26"],[1.0,"#f0f921"]]},"colorway":["#636efa","#EF553B","#00cc96","#ab63fa","#FFA15A","#19d3f3","#FF6692","#B6E880","#FF97FF","#FECB52"],"font":{"color":"#2a3f5f"},"geo":{"bgcolor":"white","lakecolor":"white","landcolor":"white","showlakes":true,"showland":true,"subunitcolor":"#C8D4E3"},"hoverlabel":{"align":"left"},"hovermode":"closest","mapbox":{"style":"light"},"paper_bgcolor":"white","plot_bgcolor":"white","polar":{"angularaxis":{"gridcolor":"#EBF0F8","linecolor":"#EBF0F8","ticks":""},"bgcolor":"white","radialaxis":{"gridcolor":"#EBF0F8","linecolor":"#EBF0F8","ticks":""}},"scene":{"xaxis":{"backgroundcolor":"white","gridcolor":"#DFE8F3","gridwidth":2,"linecolor":"#EBF0F8","showbackground":true,"ticks":"","zerolinecolor":"#EBF0F8"},"yaxis":{"backgroundcolor":"white","gridcolor":"#DFE8F3","gridwidth":2,"linecolor":"#EBF0F8","showbackground":true,"ticks":"","zerolinecolor":"#EBF0F8"},"zaxis":{"backgroundcolor":"white","gridcolor":"#DFE8F3","gridwidth":2,"linecolor":"#EBF0F8","showbackground":true,"ticks":"","zerolinecolor":"#EBF0F8"}},"shapedefaults":{"line":{"color":"#2a3f5f"}},"ternary":{"aaxis":{"gridcolor":"#DFE8F3","linecolor":"#A2B1C6","ticks":""},"baxis":{"gridcolor":"#DFE8F3","linecolor":"#A2B1C6","ticks":""},"bgcolor":"white","caxis":{"gridcolor":"#DFE8F3","linecolor":"#A2B1C6","ticks":""}},"title":{"x":0.05},"xaxis":{"automargin":true,"gridcolor":"#EBF0F8","linecolor":"#EBF0F8","ticks":"","title":{"standoff":15},"zerolinecolor":"#EBF0F8","zerolinewidth":2},"yaxis":{"automargin":true,"gridcolor":"#EBF0F8","linecolor":"#EBF0F8","ticks":"","title":{"standoff":15},"zerolinecolor":"#EBF0F8","zerolinewidth":2}}},"annotations":[{"arrowhead":2,"ax":0,"ay":-30,"bgcolor":"white","font":{"size":10},"showarrow":true,"text":"412476446244\u003cbr\u003e68,641,948","x":"2024-11-27T00:00:00","y":68641948.0},{"arrowhead":2,"ax":0,"ay":-30,"bgcolor":"white","font":{"size":10},"showarrow":true,"text":"8304555449023\u003cbr\u003e17,842,159","x":"2024-11-28T00:00:00","y":17842159.0},{"arrowhead":2,"ax":0,"ay":-30,"bgcolor":"white","font":{"size":10},"showarrow":true,"text":"9315518483834\u003cbr\u003e13,268,798","x":"2024-11-30T00:00:00","y":13268798.0},{"arrowhead":2,"ax":0,"ay":-30,"bgcolor":"white","font":{"size":10},"showarrow":true,"text":"431539048016\u003cbr\u003e8,006,467","x":"2024-11-27T00:00:00","y":8006467.0},{"arrowhead":2,"ax":0,"ay":-30,"bgcolor":"white","font":{"size":10},"showarrow":true,"text":"138455421218\u003cbr\u003e6,532,994","x":"2024-11-26T00:00:00","y":6532994.0}],"legend":{"orientation":"h","yanchor":"bottom","y":1.02,"xanchor":"center","x":0.5},"xaxis":{"title":{"text":"Transaction Date"},"tickangle":45},"title":{"text":"Daily Transaction Trends for Top 5 Customers"},"yaxis":{"title":{"text":"Total Amount"}},"hovermode":"x unified","height":600,"width":1000},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('838c8503-a176-4161-ac33-4442c23ecbd6');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>



```python

```

## 4. Top 10 Least Performing Customers per Product



```python
# Sort by highest failure rate

least = (
df.groupby(['product','Customer ID'])['Status']
.apply(lambda x:(x!="SUCCESSFUL").sum()/len(x))
.reset_index(name='failure_rate')
.sort_values(['product','failure_rate'], ascending=[True,False])
.groupby('product')
.head(10)
)
least

# # Failure Rate per Row
# summary['Failure Rate'] = summary['Failed_Count'] / summary['Total_Count']
# summary['Failure Rate']
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>product</th>
      <th>Customer ID</th>
      <th>failure_rate</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>20</th>
      <td>Airtime</td>
      <td>3315408484157</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Airtime</td>
      <td>8156589470954</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Airtime</td>
      <td>4315456478990</td>
      <td>0.85</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Airtime</td>
      <td>4373359549892</td>
      <td>0.14</td>
    </tr>
    <tr>
      <th>33</th>
      <td>Airtime</td>
      <td>8373358948958</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Airtime</td>
      <td>3733677491279</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Airtime</td>
      <td>6315476430868</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Airtime</td>
      <td>83733676454855</td>
      <td>0.03</td>
    </tr>
    <tr>
      <th>25</th>
      <td>Airtime</td>
      <td>5365347429637</td>
      <td>0.03</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Airtime</td>
      <td>7733525453138</td>
      <td>0.02</td>
    </tr>
    <tr>
      <th>45</th>
      <td>Cabletv</td>
      <td>917000447287</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Cabletv</td>
      <td>312645843913</td>
      <td>0.09</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Cabletv</td>
      <td>431539048016</td>
      <td>0.07</td>
    </tr>
    <tr>
      <th>49</th>
      <td>Cabletv</td>
      <td>8304555449023</td>
      <td>0.01</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Cabletv</td>
      <td>315468429624</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>46</th>
      <td>Cabletv</td>
      <td>1315619422232</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>47</th>
      <td>Cabletv</td>
      <td>2711999437214</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>48</th>
      <td>Cabletv</td>
      <td>7315606457522</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>50</th>
      <td>Cabletv</td>
      <td>9166616442567</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>51</th>
      <td>Cabletv</td>
      <td>53733683488385</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>68</th>
      <td>Data</td>
      <td>4373359549892</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>76</th>
      <td>Data</td>
      <td>33733665459469</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>80</th>
      <td>Data</td>
      <td>93733698412253</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>71</th>
      <td>Data</td>
      <td>6312817441723</td>
      <td>0.67</td>
    </tr>
    <tr>
      <th>78</th>
      <td>Data</td>
      <td>83733676454855</td>
      <td>0.52</td>
    </tr>
    <tr>
      <th>66</th>
      <td>Data</td>
      <td>3160254413516</td>
      <td>0.36</td>
    </tr>
    <tr>
      <th>60</th>
      <td>Data</td>
      <td>431539048016</td>
      <td>0.09</td>
    </tr>
    <tr>
      <th>61</th>
      <td>Data</td>
      <td>615674487699</td>
      <td>0.07</td>
    </tr>
    <tr>
      <th>53</th>
      <td>Data</td>
      <td>138455421218</td>
      <td>0.06</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Data</td>
      <td>315382484218</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>85</th>
      <td>Electricity</td>
      <td>917000447287</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>87</th>
      <td>Electricity</td>
      <td>2711999437214</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>88</th>
      <td>Electricity</td>
      <td>3733677491279</td>
      <td>0.50</td>
    </tr>
    <tr>
      <th>93</th>
      <td>Electricity</td>
      <td>33733678463596</td>
      <td>0.33</td>
    </tr>
    <tr>
      <th>94</th>
      <td>Electricity</td>
      <td>83733676454855</td>
      <td>0.33</td>
    </tr>
    <tr>
      <th>90</th>
      <td>Electricity</td>
      <td>8304555449023</td>
      <td>0.17</td>
    </tr>
    <tr>
      <th>81</th>
      <td>Electricity</td>
      <td>138455421218</td>
      <td>0.17</td>
    </tr>
    <tr>
      <th>86</th>
      <td>Electricity</td>
      <td>1315619422232</td>
      <td>0.12</td>
    </tr>
    <tr>
      <th>82</th>
      <td>Electricity</td>
      <td>312645843913</td>
      <td>0.05</td>
    </tr>
    <tr>
      <th>83</th>
      <td>Electricity</td>
      <td>315468429624</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>100</th>
      <td>Pin</td>
      <td>91315804436914</td>
      <td>1.00</td>
    </tr>
    <tr>
      <th>98</th>
      <td>Pin</td>
      <td>7373362945817</td>
      <td>0.22</td>
    </tr>
    <tr>
      <th>95</th>
      <td>Pin</td>
      <td>431539048016</td>
      <td>0.04</td>
    </tr>
    <tr>
      <th>96</th>
      <td>Pin</td>
      <td>2711999437214</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>97</th>
      <td>Pin</td>
      <td>5315668420288</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>99</th>
      <td>Pin</td>
      <td>8304555449023</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>101</th>
      <td>Startimes</td>
      <td>431539048016</td>
      <td>0.00</td>
    </tr>
    <tr>
      <th>102</th>
      <td>Startimes</td>
      <td>9166616442567</td>
      <td>0.00</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

# 5. From the Data, Kindly generate a summary table using the header below

### Note: Kindly share your python/R file used for the analysis. Also include notes in your code

### Customer ID,Successful Facevalue,Failed FaceValue,Estimated Gross Profit,% Value Contribution, Successful Count, Failure Rate, Airtime Failure Rate, Data Failure Rate, CableTV Failure Rate, Electricty Failure Rate


```python
df2 = pd.read_csv('/Users/mac/Downloads/Data Analyst Assessment Dataset/Assessment Dataset -.csv')

# just to see all unique status and product for possible data cleaning
df2['Status'].unique()
df2['product'].unique()

# some cleasing as done previously
#df2['product'] = df2['product'].str.capitalize()
#df2['Status'] = df2['Status'].str.upper().str.strip()
#df2['product'] = df['product'].str.upper().str.strip()
```




    array(['Data', 'Airtime', 'Cabletv', 'Electricity', 'Pin', 'Startimes'],
          dtype=object)




```python
#Categorize into sucess and failed (Basically adds two columns: Success an Failed just like how OneHotEncoding works)

df2['success'] = np.where(df2['Status'] == 'SUCCESSFUL', 1, 0)
df2['failed']  = np.where(df2['Status'] == 'SUCCESSFUL', 0, 1)
```


```python
# check
df2['success'].sum()
df2['failed'].sum()
```




    np.int64(643456)




```python
# check
df2['Status'].value_counts()
```




    Status
    SUCCESSFUL                           643456
    OTHER ERRORS                           2416
    TOO MUCH REQUESTS/SYSTEM TOO BUSY      1033
    VALIDATION ERROR                        736
    WRONG PRODUCT                           605
    Name: count, dtype: int64




```python
# add Profit column
df2['profit'] = df2['Amount'] - df2['Buying Price']

```


```python
# just to ensure pandas display numbers without scientific format
pd.set_option('display.float_format', '{:.2f}'.format) 

# Column Aggregation
summary = df2.groupby('Customer ID').agg(
    Successful_Facevalue=('Amount', lambda x: x[df2.loc[x.index, 'Status'] == 'SUCCESSFUL'].sum()),
    Failed_FaceValue=('Amount', lambda x: x[df2.loc[x.index, 'Status'] != 'SUCCESSFUL'].sum()),
    Estimated_Gross_Profit=('profit', lambda x: x[df2.loc[x.index, 'Status'] == 'SUCCESSFUL'].sum()),
    Successful_Count=('success', 'sum'), 
    Failed_Count=('failed', 'sum'), 
    Total_Count=('Tranx ID', 'count')
).reset_index()

summary.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Customer ID</th>
      <th>Successful_Facevalue</th>
      <th>Failed_FaceValue</th>
      <th>Estimated_Gross_Profit</th>
      <th>Successful_Count</th>
      <th>Failed_Count</th>
      <th>Total_Count</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>16414468728</td>
      <td>9750.00</td>
      <td>0.00</td>
      <td>162.50</td>
      <td>5</td>
      <td>0</td>
      <td>5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>138455421218</td>
      <td>41097961.00</td>
      <td>898585.00</td>
      <td>811985.00</td>
      <td>27354</td>
      <td>515</td>
      <td>27869</td>
    </tr>
    <tr>
      <th>2</th>
      <td>151172469278</td>
      <td>12450.00</td>
      <td>0.00</td>
      <td>262.50</td>
      <td>3</td>
      <td>0</td>
      <td>3</td>
    </tr>
    <tr>
      <th>3</th>
      <td>312645843913</td>
      <td>11224559.00</td>
      <td>293150.00</td>
      <td>213710.34</td>
      <td>5695</td>
      <td>68</td>
      <td>5763</td>
    </tr>
    <tr>
      <th>4</th>
      <td>315382484218</td>
      <td>38295158.00</td>
      <td>567280.00</td>
      <td>658504.91</td>
      <td>33634</td>
      <td>229</td>
      <td>33863</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Failure Rate per Row
summary['Failure Rate'] = summary['Failed_Count'] / summary['Total_Count']
summary['Failure Rate'].head()
```




    0   0.00
    1   0.02
    2   0.00
    3   0.01
    4   0.01
    Name: Failure Rate, dtype: float64




```python
# Overall Failure Rate
failure_rate_avg = (summary['Failed_Count'].sum() / summary['Total_Count'].sum())
print(f"Overall Failure Rate: {failure_rate_avg:.2%} (Which is quite fair)")

```

    Overall Failure Rate: 0.74% (Which is quite fair)



```python
# % Value Contribution
total_success_value = summary['Successful_Facevalue'].sum()

summary['% Value Contribution'] = (
    summary['Successful_Facevalue'] / total_success_value
) * 100
total_success_value
```




    np.float64(816454696.14)




```python
# Product Failure Rates
product_fail = (
    df2.groupby(['Customer ID','product'])['failed']
    .mean()
    .unstack()
)
product_fail.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>product</th>
      <th>Airtime</th>
      <th>Cabletv</th>
      <th>Data</th>
      <th>Electricity</th>
      <th>Pin</th>
      <th>Startimes</th>
    </tr>
    <tr>
      <th>Customer ID</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>16414468728</th>
      <td>0.00</td>
      <td>NaN</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>138455421218</th>
      <td>0.01</td>
      <td>NaN</td>
      <td>0.06</td>
      <td>0.17</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>151172469278</th>
      <td>0.00</td>
      <td>NaN</td>
      <td>0.00</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>312645843913</th>
      <td>0.00</td>
      <td>0.09</td>
      <td>0.04</td>
      <td>0.05</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>315382484218</th>
      <td>0.00</td>
      <td>NaN</td>
      <td>0.05</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Rename columns
product_fail = product_fail.rename(columns={
    'AIRTIME':'Airtime Failure Rate',
    'DATA':'Data Failure Rate',
    'CABLETV':'CableTV Failure Rate',
    'ELECTRICITY':'Electricty Failure Rate'
})
```


```python
# Calculate Failure Rate before merging
summary['Failure Rate'] = summary['Failed_Count'] / summary['Total_Count']
```


```python
# Merge Tables
final_table = summary.merge(
    product_fail,
    on='Customer ID',
    how='left'
)
```


```python
# Drop columns we dont need any more
# final_table = final_table.drop(
#     columns=['Failed_Count','Total_Count']
# )
```


```python
# Format all numeric columns to have commas and round to 2 decimal places
# Skip the Customer ID column
for column in final_table.columns:
    if column != 'Customer ID':
        final_table[column] = final_table[column].map('{:,.2f}'.format)

```


```python
# Spool Output
print("\nCustomer Performance Summary Table\n")
print(final_table.head(5))

```

    
    Customer Performance Summary Table
    
        Customer ID Successful_Facevalue Failed_FaceValue Estimated_Gross_Profit  \
    0   16414468728             9,750.00             0.00                 162.50   
    1  138455421218        41,097,961.00       898,585.00             811,985.00   
    2  151172469278            12,450.00             0.00                 262.50   
    3  312645843913        11,224,559.00       293,150.00             213,710.34   
    4  315382484218        38,295,158.00       567,280.00             658,504.91   
    
      Successful_Count Failed_Count Total_Count Failure Rate Airtime Cabletv  \
    0             5.00         0.00        5.00         0.00    0.00     nan   
    1        27,354.00       515.00   27,869.00         0.02    0.01     nan   
    2             3.00         0.00        3.00         0.00    0.00     nan   
    3         5,695.00        68.00    5,763.00         0.01    0.00    0.09   
    4        33,634.00       229.00   33,863.00         0.01    0.00     nan   
    
       Data Electricity  Pin Startimes  
    0  0.00         nan  nan       nan  
    1  0.06        0.17  nan       nan  
    2  0.00         nan  nan       nan  
    3  0.04        0.05  nan       nan  
    4  0.05         nan  nan       nan  



```python
# Export to CSV

final_table.to_csv("Customer_Summary_Table.csv", index=False)

print("\nOutput saved as: Updated_Customer_Summary_Table.csv")
```

    
    Output saved as: Updated_Customer_Summary_Table.csv

